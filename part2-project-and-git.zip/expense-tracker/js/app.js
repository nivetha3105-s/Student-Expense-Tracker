document.addEventListener('DOMContentLoaded', function () {

  // Auto-submit filters (month picker, category dropdown) on change
  document.querySelectorAll('[data-auto]').forEach(function (el) {
    el.addEventListener('change', function () { el.form.submit(); });
  });

  // Confirm before destructive forms (delete)
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      if (!confirm(form.getAttribute('data-confirm'))) ev.preventDefault();
    });
  });

  // Client-side validation for forms with class "js-validate"
  function setError(field, message) {
    clearError(field);
    field.classList.add('invalid');
    var span = document.createElement('span');
    span.className = 'field-error';
    span.textContent = message;
    field.parentNode.appendChild(span);
  }

  function clearError(field) {
    field.classList.remove('invalid');
    var old = field.parentNode.querySelector('.field-error');
    if (old) old.remove();
  }

  document.querySelectorAll('form.js-validate').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      var ok = true;

      form.querySelectorAll('input, select, textarea').forEach(function (f) {
        if (f.type === 'hidden' || f.offsetParent === null) return;
        clearError(f);
        var v = f.value.trim();

        if (f.required && v === '') {
          setError(f, 'This field is required.'); ok = false; return;
        }
        if (f.type === 'email' && v !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
          setError(f, 'Enter a valid email address.'); ok = false; return;
        }
        if (f.name === 'password' && f.getAttribute('minlength') && v.length < 6) {
          setError(f, 'Password must be at least 6 characters.'); ok = false; return;
        }
        if (f.name === 'amount' && v !== '' && !(parseFloat(v) > 0)) {
          setError(f, 'Amount must be greater than 0.'); ok = false; return;
        }
      });

      if (!ok) ev.preventDefault();
    });
  });
});
